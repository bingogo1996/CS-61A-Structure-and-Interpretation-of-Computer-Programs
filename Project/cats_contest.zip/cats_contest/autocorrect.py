from utils import get_common_unique_words_from_corpus

PLAYER_NAME = ''  # Change this line!


def autocorrect(user_word):
    return user_word  # Replace with your autocorrect implementation!
